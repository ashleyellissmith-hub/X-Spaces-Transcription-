const statusBox = document.getElementById('status');
const results = document.getElementById('results');
const downloads = document.getElementById('downloads');

function setStatus(message, isError = false) {
  statusBox.textContent = message;
  statusBox.classList.remove('hidden');
  statusBox.style.background = isError ? 'rgba(255,80,80,.14)' : 'rgba(178,108,255,.12)';
}

function clearList(id) {
  const el = document.getElementById(id);
  el.innerHTML = '';
  return el;
}

function fillList(id, items) {
  const el = clearList(id);
  (items || []).forEach(item => {
    const li = document.createElement('li');
    li.textContent = item;
    el.appendChild(li);
  });
}

function showResults(data) {
  const analysis = data.analysis || {};
  document.getElementById('summary').textContent = analysis.summary || 'No summary returned.';
  fillList('keyPoints', analysis.key_points);
  fillList('quotes', analysis.notable_quotes);
  fillList('postIdeas', analysis.post_ideas);
  fillList('risks', analysis.risks_or_followups);
  document.getElementById('transcript').value = data.transcript || '';

  downloads.innerHTML = '';
  if (data.transcript_download) {
    const a = document.createElement('a');
    a.href = data.transcript_download;
    a.textContent = 'Download transcript';
    downloads.appendChild(a);
  }
  if (data.summary_download) {
    const a = document.createElement('a');
    a.href = data.summary_download;
    a.textContent = 'Download summary JSON';
    downloads.appendChild(a);
  }
  results.classList.remove('hidden');
}

async function postForm(url, formData) {
  const response = await fetch(url, { method: 'POST', body: formData });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.detail || 'Something went wrong.');
  }
  return data;
}

document.getElementById('linkForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = event.target.querySelector('button');
  button.disabled = true;
  results.classList.add('hidden');
  setStatus('Extracting audio from the link, then transcribing. This can take a while for long Spaces.');
  try {
    const formData = new FormData(event.target);
    const data = await postForm('/api/transcribe-link', formData);
    setStatus('Done. Transcript and content are ready.');
    showResults(data);
  } catch (err) {
    setStatus(err.message, true);
  } finally {
    button.disabled = false;
  }
});

document.getElementById('uploadForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = event.target.querySelector('button');
  button.disabled = true;
  results.classList.add('hidden');
  setStatus('Uploading and transcribing the audio. Long recordings can take a while.');
  try {
    const formData = new FormData(event.target);
    const data = await postForm('/api/transcribe-upload', formData);
    setStatus('Done. Transcript and content are ready.');
    showResults(data);
  } catch (err) {
    setStatus(err.message, true);
  } finally {
    button.disabled = false;
  }
});
