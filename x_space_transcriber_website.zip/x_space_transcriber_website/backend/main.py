import os
import re
import uuid
import json
import shutil
import subprocess
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from openai import OpenAI

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "500"))
TRANSCRIPTION_MODEL = os.getenv("TRANSCRIPTION_MODEL", "whisper-1")
SUMMARY_MODEL = os.getenv("SUMMARY_MODEL", "gpt-4o-mini")

app = FastAPI(title="X Space Transcriber Website", version="0.1.0")
app.mount("/static", StaticFiles(directory=FRONTEND_DIR / "static"), name="static")


def get_client() -> OpenAI:
    if not os.getenv("OPENAI_API_KEY"):
        raise HTTPException(status_code=500, detail="OPENAI_API_KEY is not set on the server.")
    return OpenAI()


def safe_name(name: str) -> str:
    name = re.sub(r"[^a-zA-Z0-9._-]+", "_", name).strip("_")
    return name[:80] or "audio"


def run_command(cmd: list[str], timeout: int = 1800) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=500, detail=f"Missing required command: {cmd[0]}") from exc
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(status_code=504, detail="The extraction/conversion process timed out.") from exc


def convert_to_mp3(input_path: Path, job_id: str) -> Path:
    output_path = OUTPUT_DIR / f"{job_id}.mp3"
    cmd = [
        "ffmpeg", "-y", "-i", str(input_path),
        "-vn", "-ac", "1", "-ar", "16000", "-b:a", "64k",
        str(output_path)
    ]
    result = run_command(cmd)
    if result.returncode != 0 or not output_path.exists():
        raise HTTPException(status_code=500, detail=f"ffmpeg conversion failed: {result.stderr[-1000:]}")
    return output_path


def extract_audio_from_url(url: str, job_id: str) -> Path:
    raw_template = str(UPLOAD_DIR / f"{job_id}.%(ext)s")
    cmd = [
        "yt-dlp",
        "--no-playlist",
        "--extract-audio",
        "--audio-format", "mp3",
        "--audio-quality", "5",
        "-o", raw_template,
        url,
    ]
    result = run_command(cmd)
    if result.returncode != 0:
        raise HTTPException(
            status_code=422,
            detail=(
                "Could not extract audio from this link. The Space may be private, expired, restricted, "
                f"or X may have changed access. Try uploading the recording instead. Details: {result.stderr[-1200:]}"
            ),
        )
    matches = list(UPLOAD_DIR.glob(f"{job_id}.*"))
    mp3s = [p for p in matches if p.suffix.lower() == ".mp3"]
    if not mp3s:
        raise HTTPException(status_code=500, detail="Audio extraction appeared to complete, but no MP3 was created.")
    return mp3s[0]


def transcribe_audio(audio_path: Path) -> str:
    client = get_client()
    with audio_path.open("rb") as audio_file:
        transcript = client.audio.transcriptions.create(
            model=TRANSCRIPTION_MODEL,
            file=audio_file,
            response_format="text",
        )
    return transcript if isinstance(transcript, str) else str(transcript)


def summarise_transcript(transcript: str) -> dict:
    client = get_client()
    prompt = f"""
You are helping turn an X Space transcript into useful content.
Return valid JSON only with these keys:
summary: a plain-English summary of the Space
key_points: array of the most important points
notable_quotes: array of strong short quotes or quote-like excerpts from the transcript
post_ideas: array of short social post ideas
risks_or_followups: array of unclear claims, questions, or things worth checking

Transcript:
{transcript[:90000]}
""".strip()
    response = client.chat.completions.create(
        model=SUMMARY_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
        response_format={"type": "json_object"},
    )
    content = response.choices[0].message.content or "{}"
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        return {"summary": content, "key_points": [], "notable_quotes": [], "post_ideas": [], "risks_or_followups": []}


def save_outputs(job_id: str, transcript: str, summary: dict) -> dict:
    transcript_path = OUTPUT_DIR / f"{job_id}_transcript.txt"
    summary_path = OUTPUT_DIR / f"{job_id}_summary.json"
    transcript_path.write_text(transcript, encoding="utf-8")
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    return {
        "transcript_download": f"/download/{transcript_path.name}",
        "summary_download": f"/download/{summary_path.name}",
    }


@app.get("/", response_class=HTMLResponse)
def home():
    return (FRONTEND_DIR / "index.html").read_text(encoding="utf-8")


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/api/transcribe-link")
def transcribe_link(url: str = Form(...)):
    job_id = uuid.uuid4().hex[:12]
    audio_path = extract_audio_from_url(url, job_id)
    transcript = transcribe_audio(audio_path)
    summary = summarise_transcript(transcript)
    downloads = save_outputs(job_id, transcript, summary)
    return {"job_id": job_id, "source": "link", "transcript": transcript, "analysis": summary, **downloads}


@app.post("/api/transcribe-upload")
async def transcribe_upload(file: UploadFile = File(...)):
    job_id = uuid.uuid4().hex[:12]
    filename = safe_name(file.filename or "uploaded_audio")
    input_path = UPLOAD_DIR / f"{job_id}_{filename}"

    size = 0
    with input_path.open("wb") as buffer:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_UPLOAD_MB * 1024 * 1024:
                input_path.unlink(missing_ok=True)
                raise HTTPException(status_code=413, detail=f"File is larger than {MAX_UPLOAD_MB} MB.")
            buffer.write(chunk)

    audio_path = input_path if input_path.suffix.lower() == ".mp3" else convert_to_mp3(input_path, job_id)
    transcript = transcribe_audio(audio_path)
    summary = summarise_transcript(transcript)
    downloads = save_outputs(job_id, transcript, summary)
    return {"job_id": job_id, "source": "upload", "transcript": transcript, "analysis": summary, **downloads}


@app.get("/download/{filename}")
def download(filename: str):
    path = OUTPUT_DIR / safe_name(filename)
    if not path.exists():
        raise HTTPException(status_code=404, detail="File not found.")
    return FileResponse(path, filename=path.name)
